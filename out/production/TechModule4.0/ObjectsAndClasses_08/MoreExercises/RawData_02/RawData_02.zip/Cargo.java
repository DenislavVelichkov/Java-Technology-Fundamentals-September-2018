package ObjectsAndClasses_08.MoreExercises.RawData_02;

public class Cargo {
    private String type;
    private int weight;

    public Cargo(String type, int weight) {
        this.type = type;
        this.weight = weight;
    }
}
