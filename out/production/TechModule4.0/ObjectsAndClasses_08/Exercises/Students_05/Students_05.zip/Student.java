package ObjectsAndClasses_08.Exercises.Students_05;

public class Student {
    String name;
    String lastName;
    float grade;

    public Student(String name, String lastName, float grade) {
        this.name = name;
        this.lastName = lastName;
        this.grade = grade;
    }

    public float getGrade() {
        return grade;
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    @Override
    public String toString() {
        return String.format("%s %s: %.2f", getName(), getLastName(), getGrade());
    }
}
